<html lang="ko"><head>
<!-- META -->
<meta charset="utf-8">
<meta name="Generator" content="XpressEngine">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<!-- CSS -->
<link rel="stylesheet" type="text/css" href="/xe/layouts/dong_a_layouts/css2/flexslider.css">
<link rel="stylesheet" type="text/css" href="/xe/layouts/dong_a_layouts/css2/style.css">

</head>

<body marginwidth="0" marginheight="0">
    <div class="flexslider">
        <ul class="slides">
            <li class="mainimg01">
                
            </li>
            <li class="mainimg02">
                
            </li>
            <li class="mainimg03">
               
            </li>
        </ul>
    </div>      
        





<!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>


  <!-- FlexSlider -->
  <script defer="" src="/xe/layouts/dong_a_layouts/js2/jquery.flexslider.js"></script>

  <script type="text/javascript">
    $(function(){
      SyntaxHighlighter.all();
    });
    $(window).load(function(){
      $('.flexslider').flexslider({
        animation: "slide",
        controlNav: "thumbnails",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });
  </script>


  <!-- Syntax Highlighter -->
  <script type="text/javascript" src="/xe/layouts/dong_a_layouts/js2/shCore.js"></script>
  <script type="text/javascript" src="/xe/layouts/dong_a_layouts/js2/shBrushXml.js"></script>
  <script type="text/javascript" src="/xe/layouts/dong_a_layouts/js2/shBrushJScript.js"></script>
<script type="text/javascript" src="/xe/layouts/dong_a_layouts/js2/jquery-2.1.1.min.js"></script>
  <!-- Optional FlexSlider Additions -->
  <script src="/xe/layouts/dong_a_layouts/js2/jquery.easing.js"></script>
  <script src="/xe/layouts/dong_a_layouts/js2/jquery.mousewheel.js"></script>
  <script defer="" src="/xe/layouts/dong_a_layouts/js2/demo.js"></script>

</body></html>
